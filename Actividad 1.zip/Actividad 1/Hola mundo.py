#Programa que imprime la cadena Hola mundo
print("Hola mundo")