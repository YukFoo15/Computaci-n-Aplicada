# Programa que calcula el área de un triángulo determinado por el usuario.

base = float(input("Introduzca la medida de la base del triángulo:"))
altura = float(input("Introduzca la medida de la altura del triángulo:"))
area = (base*altura)/2
print("El área del círculo es:", area)